---
longform:
  format: scenes
  title: 工程文档
  workflow: Default Workflow
  sceneFolder: /
  scenes:
    - 1.下礼拜的工作
    - Drawing 2024-07-14 16.14.00.excalidraw
    - Index-冲突-halcyonablid_Win10
    - 简要说明
  ignoredFiles:
    - Index-冲突-095_Win10
---
