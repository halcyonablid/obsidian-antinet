

```dataviewjs

// Set the date range for the x-axis
const startDate = dv.date("2024-07-06");
const endDate = dv.date("2024-12-31");
const totalDays = (endDate - startDate) / (1000 * 60 * 60 * 24);

// Get all pages with gaocengji: true and sort them
const projects = dv.pages()
    .where(p => p.gaocengji === true)
    .sort(p => p.qishiriqidate);

// Create the chart
dv.paragraph(createChart(projects));

function createChart(projects) {
    const chartWidth = 2000; // Increased chart width
    const rowHeight = 30;
    const labelWidth = 150;
    const dateHeight = 100; // Height for vertical date labels
    const today = dv.date("today");

    let chart = `<div style="display: flex;">
        <div style="width: ${labelWidth}px; position: relative;">`;

    // Add project labels as clickable links on the left
    projects.forEach((p, index) => {
        chart += `<div style="position: absolute; left: 5px; top: ${(index + 1) * rowHeight + dateHeight}px; width: ${labelWidth - 10}px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
            <a href="${p.file.path}" title="${p.file.name}">${p.file.name}</a>
        </div>`;
    });

    chart += `</div>
        <div style="width: calc(100% - ${labelWidth}px); overflow-x: auto;">
            <div style="width: ${chartWidth}px; height: ${(projects.length + 1) * rowHeight + dateHeight}px; position: relative;">`;

    // Create week labels and vertical lines
    let currentDate = new Date(startDate.toJSDate());
    let prevMonday = null;
    while (currentDate <= endDate.toJSDate()) {
        const daysPassed = (currentDate - startDate.toJSDate()) / (1000 * 60 * 60 * 24);
        const left = (daysPassed / totalDays) * chartWidth;
        
        if (currentDate.getDay() === 1) { // Monday
            // Add vertical line for Monday
            chart += `<div style="position: absolute; left: ${left}px; top: ${dateHeight}px; bottom: 0; width: 1px; background-color: #ddd;"></div>`;
            
            // Add date label
            chart += `<div style="position: absolute; left: ${left}px; top: 0; transform: translateX(-50%);">
                <div style="white-space: nowrap; font-size: 10px;">
                    ${formatDate(currentDate)}
                </div>
            </div>`;

            // Add week number label
            if (prevMonday) {
                const prevLeft = ((prevMonday - startDate.toJSDate()) / (1000 * 60 * 60 * 24) / totalDays) * chartWidth;
                const weekNumber = getWeekNumber(prevMonday);
                chart += `<div style="position: absolute; left: ${(left + prevLeft) / 2}px; top: ${dateHeight / 2}px; transform: translateX(-50%);">
                    <div style="white-space: nowrap; font-size: 10px;">
                        W${weekNumber}
                    </div>
                </div>`;
            }
            prevMonday = new Date(currentDate);
        }

        currentDate.setDate(currentDate.getDate() + 1);
    }

    // Add the last week number
    if (prevMonday) {
        const lastLeft = ((prevMonday - startDate.toJSDate()) / (1000 * 60 * 60 * 24) / totalDays) * chartWidth;
        const weekNumber = getWeekNumber(prevMonday);
        chart += `<div style="position: absolute; left: ${(chartWidth + lastLeft) / 2}px; top: ${dateHeight / 2}px; transform: translateX(-50%);">
            <div style="white-space: nowrap; font-size: 10px;">
                W${weekNumber}
            </div>
        </div>`;
    }

    // Add red line for current date
    const todayOffset = ((today - startDate) / (endDate - startDate)) * chartWidth;
    if (todayOffset >= 0 && todayOffset <= chartWidth) {
        chart += `<div style="position: absolute; left: ${todayOffset}px; top: ${dateHeight}px; bottom: 0; width: 2px; background-color: red; z-index: 1;"></div>`;
    }

    // Create project bars
    projects.forEach((p, index) => {
        const start = p.qishiriqidate ? dv.date(p.qishiriqidate) : null;
        const end = p.duedate ? dv.date(p.duedate) : null;
        
        if (start && end) {
            const projectStart = Math.max(0, ((start - startDate) / (endDate - startDate)) * chartWidth);
            const projectWidth = Math.min(chartWidth - projectStart, ((end - start) / (endDate - startDate)) * chartWidth);
            
            chart += `<div style="position: absolute; left: 0; top: ${(index + 1) * rowHeight + dateHeight}px; height: ${rowHeight - 5}px; width: ${chartWidth}px;">
                <div style="position: absolute; left: ${projectStart}px; width: ${projectWidth}px; height: 100%; background: blue;">
                    <span style="position: absolute; left: 2px; top: 2px; font-size: 8px; color: white;">${formatDate(start)}</span>
                    <span style="position: absolute; right: 2px; bottom: 2px; font-size: 8px; color: white;">${formatDate(end)}</span>
                </div>`;
            
            // Handle multiple sprints
            if (p.sprints && Array.isArray(p.sprints)) {
                p.sprints.forEach(sprint => {
                    const sprintStart = dv.date(sprint.start);
                    const sprintEnd = dv.date(sprint.end);
                    if (sprintStart && sprintEnd) {
                        const sprintStartOffset = Math.max(0, ((sprintStart - startDate) / (endDate - startDate)) * chartWidth);
                        const sprintWidth = Math.min(chartWidth - sprintStartOffset, ((sprintEnd - sprintStart) / (endDate - startDate)) * chartWidth);
                        
                        chart += `<div class="sprint-bar" style="position: absolute; left: ${sprintStartOffset}px; width: ${sprintWidth}px; height: 100%; background: orange;" title="${sprint.goal || ''}">
                            <span style="position: absolute; left: 2px; top: 2px; font-size: 8px; color: black;">${formatDate(sprintStart)}</span>
                            <span style="position: absolute; right: 2px; bottom: 2px; font-size: 8px; color: black;">${formatDate(sprintEnd)}</span>
                            <span style="position: absolute; left: 2px; bottom: 2px; font-size: 8px; color: black; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: calc(100% - 4px);">${sprint.goal || ''}</span>
                        </div>`;
                    }
                });
            }
            
            chart += `</div>`;
        }
    });
    
    chart += `</div></div></div>`;

    // Add CSS for hover effect
    chart += `
    <style>
    .sprint-bar {
        position: relative;
    }
    .sprint-bar:hover::after {
        content: attr(title);
        position: absolute;
        left: 50%;
        top: 100%;
        transform: translateX(-50%);
        background: white;
        border: 1px solid black;
        padding: 5px;
        z-index: 1000;
        white-space: nowrap;
    }
    </style>`;

    return chart;
}

function formatDate(date) {
    if (!date) return '';
    return date instanceof Date ? `${date.getMonth() + 1}-${date.getDate()}` : date.toFormat ? date.toFormat('MM-dd') : '';
}

function getWeekNumber(d) {
    d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay()||7));
    var yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
    var weekNo = Math.ceil(( ( (d - yearStart) / 86400000) + 1)/7);
    return weekNo;
}

```
