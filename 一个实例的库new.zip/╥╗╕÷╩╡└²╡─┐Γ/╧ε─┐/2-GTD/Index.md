---
longform:
  format: scenes
  title: 002-GTD
  workflow: Default Workflow
  sceneFolder: /
  scenes:
    - 日程计划
    - ATOM- 待办事项
    - P-项目清单
    - Homepage
    - G-目标和愿景
    - GTD所包含的类别
  ignoredFiles: []
---
