---
longform:
  format: scenes
  title: 001-资料库
  workflow: Default Workflow
  sceneFolder: /
  scenes:
    - ZL-资料
    - 三明治的制作食谱
  ignoredFiles: []
---
