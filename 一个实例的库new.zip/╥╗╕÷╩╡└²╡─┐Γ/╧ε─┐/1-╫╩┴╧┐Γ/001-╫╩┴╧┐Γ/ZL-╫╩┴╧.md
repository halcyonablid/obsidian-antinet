parent::[[GTD所包含的类别]]

