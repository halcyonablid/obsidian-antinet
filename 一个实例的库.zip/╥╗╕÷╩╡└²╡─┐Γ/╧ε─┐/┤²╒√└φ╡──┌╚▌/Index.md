---
longform:
  format: scenes
  title: 000- 待整理的内容
  workflow: Default Workflow
  sceneFolder: /
  scenes:
    - cloud garden计划
    - 未命名
  ignoredFiles: []
---
