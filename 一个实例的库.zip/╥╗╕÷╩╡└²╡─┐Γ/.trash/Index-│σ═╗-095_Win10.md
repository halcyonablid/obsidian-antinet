---
longform:
  format: scenes
  title: 工程文档
  workflow: Default Workflow
  sceneFolder: /
  scenes:
    - 1.下礼拜的工作
  ignoredFiles: []
---
